
public class InvalidMoveException extends RuntimeException {

}
